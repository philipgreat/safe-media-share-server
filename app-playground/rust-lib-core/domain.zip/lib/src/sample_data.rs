
use std::collections::BTreeMap;
use crate::TeaqlRuntime;
use crate::Q;
use teaql_core::Entity as _;
use crate::request_support::AuditedSave as _;

pub trait IntoU64 {
    fn into_u64(self) -> u64;
}

impl IntoU64 for u64 {
    fn into_u64(self) -> u64 {
        self
    }
}

impl IntoU64 for Option<&teaql_core::Value> {
    fn into_u64(self) -> u64 {
        self.and_then(|v| v.try_u64()).unwrap_or_default()
    }
}

#[derive(Debug, Copy, Clone)]
pub enum SampleDataScale {
    Tiny,
    Small,
    Medium,
}

pub struct SampleDataPlan {
    pub scale: SampleDataScale,
    pub seed: u64,
}

impl SampleDataPlan {
    pub fn small() -> Self {
        Self {
            scale: SampleDataScale::Small,
            seed: 0,
        }
    }
}

pub struct SampleDataReport {
    pub generated: BTreeMap<&'static str, usize>,
    pub skipped: Vec<SampleDataSkipped>,
}

pub struct SampleDataSkipped {
    pub entity: &'static str,
    pub reason: String,
}

#[derive(Debug)]
pub struct SampleDataError {
    message: String,
}

impl SampleDataError {
    fn from_display(error: impl std::fmt::Display) -> Self {
        Self {
            message: error.to_string(),
        }
    }
}

impl std::fmt::Display for SampleDataError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str(&self.message)
    }
}

impl std::error::Error for SampleDataError {}

pub struct SampleDataState {
    pub plan: SampleDataPlan,
    pub references: BTreeMap<&'static str, Vec<u64>>,
    pub generated: BTreeMap<&'static str, usize>,
    pub skipped: Vec<SampleDataSkipped>,
}

impl SampleDataState {
    pub fn new(plan: SampleDataPlan) -> Self {
        Self {
            plan,
            references: BTreeMap::new(),
            generated: BTreeMap::new(),
            skipped: Vec::new(),
        }
    }

    pub fn add_reference(&mut self, entity: &'static str, id: u64) {
        self.references.entry(entity).or_default().push(id);
    }

    pub fn ids(&self, entity: &'static str) -> &[u64] {
        self.references.get(entity).map(|v| v.as_slice()).unwrap_or(&[])
    }

    pub fn pick_id(&self, entity: &'static str, salt: usize) -> Option<u64> {
        let ids = self.ids(entity);
        if ids.is_empty() {
            None
        } else {
            Some(ids[salt % ids.len()])
        }
    }

    pub fn pick_unused_id(&self, entity: &'static str, salt: usize, used: &std::collections::HashSet<u64>) -> Option<u64> {
        let ids = self.ids(entity);
        if ids.is_empty() {
            return None;
        }

        let best_id = ids[salt % ids.len()];
        if !used.contains(&best_id) {
            return Some(best_id);
        }

        for id in ids {
            if !used.contains(id) {
                return Some(*id);
            }
        }

        Some(best_id)
    }

    pub fn record_generated(&mut self, entity: &'static str) {
        *self.generated.entry(entity).or_default() += 1;
    }

    pub fn record_skipped(&mut self, entity: &'static str, reason: String) {
        self.skipped.push(SampleDataSkipped { entity, reason });
    }

    pub fn into_report(self) -> SampleDataReport {
        SampleDataReport {
            generated: self.generated,
            skipped: self.skipped,
        }
    }
}

pub async fn generate_sample_data<C>(
    context: &C,
    plan: SampleDataPlan,
) -> Result<SampleDataReport, SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
    log::info!("Starting sample data generation. Scale: {:?}, Seed: {}", plan.scale, plan.seed);
    let mut state = SampleDataState::new(plan);

    load_root_media_libraries(context, &mut state).await?; //depth: 0

    load_constant_grant_statuses(context, &mut state).await?;
    load_constant_invite_statuses(context, &mut state).await?;

    generate_app_settings(context, &mut state).await?;

    generate_media_assets(context, &mut state).await?;

    generate_proxy_trust_rules(context, &mut state).await?;

    generate_invite_codes(context, &mut state).await?;

    generate_ip_access_grants(context, &mut state).await?;

    generate_share_handles(context, &mut state).await?;


    let report = state.into_report();
    log::info!("Sample data generation completed successfully. Generated: {} tables, Skipped: {} tables.", report.generated.len(), report.skipped.len());
    Ok(report)
}

async fn load_root_media_libraries<C>(
    context: &C,
    state: &mut SampleDataState,
) -> Result<(), SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
    let list = Q::media_libraries().comment("what: inspect existing entities before sample-data initialization").purpose("why: avoid duplicate sample records").execute_for_list(context).await.unwrap_or_default();
    for item in list {
        state.add_reference(crate::MediaLibrary::ENTITY_NAME, item.id().into_u64());
    }
    Ok(())
}

async fn load_constant_grant_statuses<C>(
    context: &C,
    state: &mut SampleDataState,
) -> Result<(), SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
    let list = Q::grant_statuses().comment("what: inspect existing entities before sample-data initialization").purpose("why: avoid duplicate sample records").execute_for_list(context).await.unwrap_or_default();
    for item in list {
        state.add_reference(crate::GrantStatus::ENTITY_NAME, item.id().into_u64());
    }
    Ok(())
}

async fn load_constant_invite_statuses<C>(
    context: &C,
    state: &mut SampleDataState,
) -> Result<(), SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
    let list = Q::invite_statuses().comment("what: inspect existing entities before sample-data initialization").purpose("why: avoid duplicate sample records").execute_for_list(context).await.unwrap_or_default();
    for item in list {
        state.add_reference(crate::InviteStatus::ENTITY_NAME, item.id().into_u64());
    }
    Ok(())
}

async fn generate_app_settings<C>(
    context: &C,
    state: &mut SampleDataState,
) -> Result<(), SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
        if state.ids("Media Library").is_empty() {
            state.record_skipped(crate::AppSetting::ENTITY_NAME, "Required dependency Media Library is missing in reference pool".to_string());
            log::info!("Skipped generating App Setting: Required dependency Media Library is missing in reference pool.");
            return Ok(());
        }


    let object_fields_count = 0 + 1;
    let base_fanout = std::cmp::max(1, object_fields_count) * 20;

    let fanout = match state.plan.scale {
        SampleDataScale::Tiny => base_fanout,
        SampleDataScale::Small => base_fanout * 5,
        SampleDataScale::Medium => base_fanout * 50,
    };

    log::info!("Generating sample data for App Setting (expected: {})...", fanout);

    for i in 0..fanout {
        let mut entity = Q::app_settings().comment("what: initialize a sample entity").purpose("why: populate the requested sample dataset").new_entity(context);
        let mut used_refs = std::collections::HashSet::<u64>::new();

                if let Some(ref_id) = state.pick_unused_id("Media Library", i as usize, &used_refs) {
                    entity.update_media_library_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                entity.update_setting_key(format!("{} {}", "external_base_url", i + 1));

                entity.update_setting_value(format!("{} {}", "https://media.example.com", i + 1));

                entity.update_setting_name(format!("{} {}", "外部访问 URL 前缀", i + 1));

                entity.update_setting_note(format!("{} {}", "复制邀请链接与打开链接时使用的对外地址前缀", i + 1));

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_create_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_update_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }



entity.audit_as("Init Sample Data").save(context).await.map_err(SampleDataError::from_display)?;

        state.record_generated(crate::AppSetting::ENTITY_NAME);

        if i % 20 == 0 {
            log::info!("Generating App Setting: {}/{}", i, fanout);
        }

    }

    log::info!("Successfully generated sample records for App Setting.");
    Ok(())
}


async fn generate_media_assets<C>(
    context: &C,
    state: &mut SampleDataState,
) -> Result<(), SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
        if state.ids("Media Library").is_empty() {
            state.record_skipped(crate::MediaAsset::ENTITY_NAME, "Required dependency Media Library is missing in reference pool".to_string());
            log::info!("Skipped generating Media Asset: Required dependency Media Library is missing in reference pool.");
            return Ok(());
        }


    let object_fields_count = 0 + 1;
    let base_fanout = std::cmp::max(1, object_fields_count) * 20;

    let fanout = match state.plan.scale {
        SampleDataScale::Tiny => base_fanout,
        SampleDataScale::Small => base_fanout * 5,
        SampleDataScale::Medium => base_fanout * 50,
    };

    log::info!("Generating sample data for Media Asset (expected: {})...", fanout);

    for i in 0..fanout {
        let mut entity = Q::media_assets().comment("what: initialize a sample entity").purpose("why: populate the requested sample dataset").new_entity(context);
        let mut used_refs = std::collections::HashSet::<u64>::new();

                if let Some(ref_id) = state.pick_unused_id("Media Library", i as usize, &used_refs) {
                    entity.update_media_library_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                entity.update_display_name(format!("{} {}", "Demo Video", i + 1));

                entity.update_file_path(format!("{} {}", "videos/demo.mp4", i + 1));

                entity.update_content_type(format!("{} {}", "video/mp4", i + 1));

                {
                    let max_val: u64 = "1048576".parse().unwrap_or(1000);
                    let rand_val = (i as u64 + state.plan.seed) % max_val.max(1) + 1;
                    entity.update_file_size(rand_val as i64);
                }

                {
                    let max_val: u64 = "120".parse().unwrap_or(1000);
                    let rand_val = (i as u64 + state.plan.seed) % max_val.max(1) + 1;
                    entity.update_duration_seconds(rand_val as i64);
                }

                entity.update_active(true);

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_create_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_update_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }



        let entity = entity.audit_as("Init Sample Data").save(context).await.map_err(SampleDataError::from_display)?;

        state.record_generated(crate::MediaAsset::ENTITY_NAME);

        if i % 20 == 0 {
            log::info!("Generating Media Asset: {}/{}", i, fanout);
        }

        state.add_reference(crate::MediaAsset::ENTITY_NAME, entity.id().into_u64());
    }

    log::info!("Successfully generated sample records for Media Asset.");
    Ok(())
}


async fn generate_proxy_trust_rules<C>(
    context: &C,
    state: &mut SampleDataState,
) -> Result<(), SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
        if state.ids("Media Library").is_empty() {
            state.record_skipped(crate::ProxyTrustRule::ENTITY_NAME, "Required dependency Media Library is missing in reference pool".to_string());
            log::info!("Skipped generating Proxy Trust Rule: Required dependency Media Library is missing in reference pool.");
            return Ok(());
        }


    let object_fields_count = 0 + 1;
    let base_fanout = std::cmp::max(1, object_fields_count) * 20;

    let fanout = match state.plan.scale {
        SampleDataScale::Tiny => base_fanout,
        SampleDataScale::Small => base_fanout * 5,
        SampleDataScale::Medium => base_fanout * 50,
    };

    log::info!("Generating sample data for Proxy Trust Rule (expected: {})...", fanout);

    for i in 0..fanout {
        let mut entity = Q::proxy_trust_rules().comment("what: initialize a sample entity").purpose("why: populate the requested sample dataset").new_entity(context);
        let mut used_refs = std::collections::HashSet::<u64>::new();

                if let Some(ref_id) = state.pick_unused_id("Media Library", i as usize, &used_refs) {
                    entity.update_media_library_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                entity.update_header_name(format!("{} {}", "X-Forwarded-For", i + 1));

                entity.update_trusted_proxy_cidrs(format!("{} {}", "10.0.0.0/8", i + 1));

                entity.update_enabled(true);

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_create_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_update_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }



entity.audit_as("Init Sample Data").save(context).await.map_err(SampleDataError::from_display)?;

        state.record_generated(crate::ProxyTrustRule::ENTITY_NAME);

        if i % 20 == 0 {
            log::info!("Generating Proxy Trust Rule: {}/{}", i, fanout);
        }

    }

    log::info!("Successfully generated sample records for Proxy Trust Rule.");
    Ok(())
}


async fn generate_invite_codes<C>(
    context: &C,
    state: &mut SampleDataState,
) -> Result<(), SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
        if state.ids("Media Library").is_empty() {
            state.record_skipped(crate::InviteCode::ENTITY_NAME, "Required dependency Media Library is missing in reference pool".to_string());
            log::info!("Skipped generating Invite Code: Required dependency Media Library is missing in reference pool.");
            return Ok(());
        }

        if state.ids("Media Asset").is_empty() {
            state.record_skipped(crate::InviteCode::ENTITY_NAME, "Required dependency Media Asset is missing in reference pool".to_string());
            log::info!("Skipped generating Invite Code: Required dependency Media Asset is missing in reference pool.");
            return Ok(());
        }

        if state.ids("Invite Status").is_empty() {
            state.record_skipped(crate::InviteCode::ENTITY_NAME, "Required dependency Invite Status is missing in reference pool".to_string());
            log::info!("Skipped generating Invite Code: Required dependency Invite Status is missing in reference pool.");
            return Ok(());
        }


    let object_fields_count = 0 + 1 + 1 + 1;
    let base_fanout = std::cmp::max(1, object_fields_count) * 20;

    let fanout = match state.plan.scale {
        SampleDataScale::Tiny => base_fanout,
        SampleDataScale::Small => base_fanout * 5,
        SampleDataScale::Medium => base_fanout * 50,
    };

    log::info!("Generating sample data for Invite Code (expected: {})...", fanout);

    for i in 0..fanout {
        let mut entity = Q::invite_codes().comment("what: initialize a sample entity").purpose("why: populate the requested sample dataset").new_entity(context);
        let mut used_refs = std::collections::HashSet::<u64>::new();

                if let Some(ref_id) = state.pick_unused_id("Media Library", i as usize, &used_refs) {
                    entity.update_media_library_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                if let Some(ref_id) = state.pick_unused_id("Media Asset", i as usize, &used_refs) {
                    entity.update_media_asset_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                if let Some(ref_id) = state.pick_unused_id("Invite Status", i as usize, &used_refs) {
                    entity.update_invite_status_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                entity.update_invite_token(format!("{} {}", "INV-7f3a9c2e5b1d", i + 1));

                entity.update_first_client_ip(format!("{} {}", "192.168.1.100", i + 1));

                entity.update_first_click_at(format!("{} {}", "00:00", i + 1));

                entity.update_second_client_ip(format!("{} {}", "192.168.1.200", i + 1));

                entity.update_second_click_at(format!("{} {}", "00:00", i + 1));

                entity.update_grant_note(format!("{} {}", "One-shot invite link for demo video", i + 1));

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_create_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_update_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }



entity.audit_as("Init Sample Data").save(context).await.map_err(SampleDataError::from_display)?;

        state.record_generated(crate::InviteCode::ENTITY_NAME);

        if i % 20 == 0 {
            log::info!("Generating Invite Code: {}/{}", i, fanout);
        }

    }

    log::info!("Successfully generated sample records for Invite Code.");
    Ok(())
}


async fn generate_ip_access_grants<C>(
    context: &C,
    state: &mut SampleDataState,
) -> Result<(), SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
        if state.ids("Media Library").is_empty() {
            state.record_skipped(crate::IpAccessGrant::ENTITY_NAME, "Required dependency Media Library is missing in reference pool".to_string());
            log::info!("Skipped generating IP Access Grant: Required dependency Media Library is missing in reference pool.");
            return Ok(());
        }

        if state.ids("Media Asset").is_empty() {
            state.record_skipped(crate::IpAccessGrant::ENTITY_NAME, "Required dependency Media Asset is missing in reference pool".to_string());
            log::info!("Skipped generating IP Access Grant: Required dependency Media Asset is missing in reference pool.");
            return Ok(());
        }

        if state.ids("Grant Status").is_empty() {
            state.record_skipped(crate::IpAccessGrant::ENTITY_NAME, "Required dependency Grant Status is missing in reference pool".to_string());
            log::info!("Skipped generating IP Access Grant: Required dependency Grant Status is missing in reference pool.");
            return Ok(());
        }


    let object_fields_count = 0 + 1 + 1 + 1;
    let base_fanout = std::cmp::max(1, object_fields_count) * 20;

    let fanout = match state.plan.scale {
        SampleDataScale::Tiny => base_fanout,
        SampleDataScale::Small => base_fanout * 5,
        SampleDataScale::Medium => base_fanout * 50,
    };

    log::info!("Generating sample data for IP Access Grant (expected: {})...", fanout);

    for i in 0..fanout {
        let mut entity = Q::ip_access_grants().comment("what: initialize a sample entity").purpose("why: populate the requested sample dataset").new_entity(context);
        let mut used_refs = std::collections::HashSet::<u64>::new();

                if let Some(ref_id) = state.pick_unused_id("Media Library", i as usize, &used_refs) {
                    entity.update_media_library_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                if let Some(ref_id) = state.pick_unused_id("Media Asset", i as usize, &used_refs) {
                    entity.update_media_asset_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                if let Some(ref_id) = state.pick_unused_id("Grant Status", i as usize, &used_refs) {
                    entity.update_grant_status_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                entity.update_client_ip(format!("{} {}", "192.168.1.100", i + 1));

                entity.update_expire_at(format!("{} {}", "52:00", i + 1));

                entity.update_grant_note(format!("{} {}", "Home network access for demo", i + 1));

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_create_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_update_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }



entity.audit_as("Init Sample Data").save(context).await.map_err(SampleDataError::from_display)?;

        state.record_generated(crate::IpAccessGrant::ENTITY_NAME);

        if i % 20 == 0 {
            log::info!("Generating IP Access Grant: {}/{}", i, fanout);
        }

    }

    log::info!("Successfully generated sample records for IP Access Grant.");
    Ok(())
}


async fn generate_share_handles<C>(
    context: &C,
    state: &mut SampleDataState,
) -> Result<(), SampleDataError>
where
    C: TeaqlRuntime + ?Sized,
{
        if state.ids("Media Library").is_empty() {
            state.record_skipped(crate::ShareHandle::ENTITY_NAME, "Required dependency Media Library is missing in reference pool".to_string());
            log::info!("Skipped generating Share Handle: Required dependency Media Library is missing in reference pool.");
            return Ok(());
        }

        if state.ids("Media Asset").is_empty() {
            state.record_skipped(crate::ShareHandle::ENTITY_NAME, "Required dependency Media Asset is missing in reference pool".to_string());
            log::info!("Skipped generating Share Handle: Required dependency Media Asset is missing in reference pool.");
            return Ok(());
        }


    let object_fields_count = 0 + 1 + 1;
    let base_fanout = std::cmp::max(1, object_fields_count) * 20;

    let fanout = match state.plan.scale {
        SampleDataScale::Tiny => base_fanout,
        SampleDataScale::Small => base_fanout * 5,
        SampleDataScale::Medium => base_fanout * 50,
    };

    log::info!("Generating sample data for Share Handle (expected: {})...", fanout);

    for i in 0..fanout {
        let mut entity = Q::share_handles().comment("what: initialize a sample entity").purpose("why: populate the requested sample dataset").new_entity(context);
        let mut used_refs = std::collections::HashSet::<u64>::new();

                if let Some(ref_id) = state.pick_unused_id("Media Library", i as usize, &used_refs) {
                    entity.update_media_library_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                if let Some(ref_id) = state.pick_unused_id("Media Asset", i as usize, &used_refs) {
                    entity.update_media_asset_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                entity.update_handle_token(format!("{} {}", "SHD-7f3a9c2e5b1d", i + 1));

                entity.update_active(true);

                entity.update_handle_note(format!("{} {}", "Durable cross-session open link for demo video", i + 1));

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_create_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_update_time(teaql_core::time::Timestamp(past.and_utc().timestamp_millis()));
                }



entity.audit_as("Init Sample Data").save(context).await.map_err(SampleDataError::from_display)?;

        state.record_generated(crate::ShareHandle::ENTITY_NAME);

        if i % 20 == 0 {
            log::info!("Generating Share Handle: {}/{}", i, fanout);
        }

    }

    log::info!("Successfully generated sample records for Share Handle.");
    Ok(())
}
